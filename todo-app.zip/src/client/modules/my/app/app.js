import { LightningElement, api } from 'lwc';

export default class App extends LightningElement {
    renderedCallback() {
        this.template.querySelector('.manual').innerHTML = '<todo-app-main-page baseurl="/api"></todo-app-main-page>';
    }
}
